﻿using System;
using System.Threading;
namespace Countdown
{
    class Program
    {
        static TimeSpan originalTime;
        static TimeSpan timeLeft;
        static bool isRunning = false;
        static bool exitRequested = false;
        static bool countdownComplete = false;
        static object lockObj = new object();
        static void Main()
        {
            Console.Clear();
            Console.WriteLine("=== COUNTDOWN ===");
            Console.Write("Enter minutes: ");
            int minutes = ReadPositiveInt();
            Console.Write("Enter seconds: ");
            int seconds = ReadPositiveInt(59);

            if (minutes == 0 && seconds == 0)
            {
                Console.WriteLine("Timer must be greater than 0 seconds.");
                return;
            }
            originalTime = new TimeSpan(0, minutes, seconds);
            timeLeft = originalTime;

            Thread timerThread = new Thread(RunTimer);
            timerThread.Start();

            while (!exitRequested)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                switch (key.Key)
                {
                    case ConsoleKey.Spacebar:
                        lock (lockObj)
                        {
                            if (!countdownComplete)
                            {
                                isRunning = !isRunning;
                            }
                        }
                        break;
                    case ConsoleKey.R:
                        lock (lockObj)
                        {
                            timeLeft = originalTime;
                            isRunning = false;
                            countdownComplete = false;
                        }
                        break;
                    case ConsoleKey.Q:
                        lock (lockObj)
                        {
                            exitRequested = true;
                        }
                        break;
                }
            }
            timerThread.Join();
            Console.Clear();
            Console.WriteLine("Quitting...");
            Thread.Sleep(1000);
        }
        static void RunTimer()
        {
            while (!exitRequested)
            {
                lock (lockObj)
                {
                    Console.Clear();
                    Console.WriteLine("=== COUNTDOWN TIMER ===");

                    if (countdownComplete)
                    {
                        Console.WriteLine("Countdown complete!");
                    }
                    else
                    {
                        Console.WriteLine($"Time left: {timeLeft.Minutes:D2}:{timeLeft.Seconds:D2}");
                        Console.WriteLine($"Status: {(isRunning ? "Running" : "Paused")}");
                    }
                    Console.WriteLine("Space = Start/Pause | R = Reset | Q = Quit");
                    if (isRunning && timeLeft.TotalSeconds > 0)
                    {
                        timeLeft = timeLeft.Subtract(TimeSpan.FromSeconds(1));
                    }
                    else if (isRunning && timeLeft.TotalSeconds <= 0)
                    {
                        isRunning = false;
                        countdownComplete = true;
                    }
                }
                Thread.Sleep(1000);
            }
        }
        static int ReadPositiveInt(int max = int.MaxValue)
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (int.TryParse(input, out int value) && value >= 0 && value <= max)
                    return value;
                Console.Write("Invalid input. Try again: ");
            }
        }
    }
}